package com.example.projecttest2;

import android.content.Intent;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;

public class ContentWriteActivity extends AppCompatActivity {

    private TextInputEditText content;
    private String text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_content_write);

        checkContent();
    }

    public void checkContent() {
        content = (TextInputEditText) findViewById(R.id.content);
        content.addTextChangedListener(new TextWatcher() {
            @Override // 입력하기 전에
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }
            @Override // 입력되는 텍스트에 변화가 있을 때
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                text = content.getText().toString();
            }
            @Override // 입력이 끝났을 때
            public void afterTextChanged(Editable arg0) {

            }
        });
    }

    // 안드로이드 백버튼 막기;
    @Override
    public void onBackPressed() {
        return;
    }

    //바깥레이어 클릭시 안닫히게
    @Override
    public boolean onTouchEvent(MotionEvent event) {

        if(event.getAction()== MotionEvent.ACTION_OUTSIDE){
            return false;
        }
        return true;
    }

    // 확인 버튼 클릭
    public void OnOK(View v) {
        //데이터 전달하기
        Intent intent = new Intent();
        intent.putExtra("result", text);
        setResult(RESULT_OK, intent);

        //액티비티(팝업) 닫기
        finish();
    }

    // 취소 버튼 클릭
    public void OnCancel(View v) {
        finish(); // 종료
    }

}
