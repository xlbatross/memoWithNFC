package com.example.projecttest2.mainCategoryView.item;

import com.example.projecttest2.vo.Memo;

public class MemoItem extends Item {
    public Memo memo;

    public MemoItem(Memo memo) {
        this.viewType = 1;
        this.memo = memo;
    }
}
