package com.example.projecttest2.mainCategoryView.item;

public abstract class Item {
    public int viewType;
}
