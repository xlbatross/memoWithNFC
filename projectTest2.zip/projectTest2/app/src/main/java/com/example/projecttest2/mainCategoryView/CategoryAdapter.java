package com.example.projecttest2.mainCategoryView;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.example.projecttest2.R;
import com.example.projecttest2.db.DBHelper;
import com.example.projecttest2.mainCategoryView.item.CategoryItem;
import com.example.projecttest2.mainCategoryView.item.Item;
import com.example.projecttest2.mainCategoryView.item.MemoItem;
import com.example.projecttest2.vo.Category;
import com.example.projecttest2.vo.Memo;

import java.util.ArrayList;

public class CategoryAdapter extends  RecyclerView.Adapter<RecyclerView.ViewHolder>{
    private Context context;
    private DBHelper db;

    private final int CATEGORY_ITEM_VIEW = 0;
    private final int MEMO_ITEM_VIEW = 1;
    private final int MEMO_VIEW_COUNT = 2;
    private ArrayList<Item> visibleItems = new ArrayList<>();

    public CategoryAdapter(Context context, DBHelper db) {
        this.context = context;
        this.db = db;

        ArrayList<Category> cList = new ArrayList<>(this.db.getAllCategories());
        for(Category cg : cList) {
            visibleItems.add(new CategoryItem(cg));
            CategoryItem cgi = (CategoryItem) visibleItems.get(visibleItems.size() - 1);
            ArrayList<Memo> mms = new ArrayList<>(this.db.getAllMemosByCategory(cg.getId()));
            if(mms.size() != 0) {
                int i = visibleItems.size();
                for(Memo mm : mms) {
                    if(visibleItems.size() - i >= MEMO_VIEW_COUNT )
                        cgi.unvisibleMemoItems.add(new MemoItem(mm));
                    else if(visibleItems.size() - i < MEMO_VIEW_COUNT ) {
                        cgi.visibleMemoSize += 1;
                        visibleItems.add(new MemoItem(mm));
                    }
                }
            }
        }
    }

    @Override
    public int getItemCount() {
        return (visibleItems != null ? visibleItems.size() : 0);
    }

    @Override
    public int getItemViewType(int position) {
        return visibleItems.get(position).viewType;
    }

    // RecyclerView에 새로운 데이터를 보여주기 위해 필요한 ViewHolder를 생성해야 할 때 호출됩니다.
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        switch(viewType) {
            case CATEGORY_ITEM_VIEW :
                View view = LayoutInflater.from(context)
                        .inflate(R.layout.category, viewGroup, false);
                viewHolder = new CategoryViewHolder(view);
                break;
            case MEMO_ITEM_VIEW :
                View subview = LayoutInflater.from(context)
                        .inflate(R.layout.memo, viewGroup, false);
                viewHolder = new MemoViewHolder(subview);
                break;
        }

        return viewHolder;
    }

    // Adapter의 특정 위치(position)에 있는 데이터를 보여줘야 할때 호출됩니다.
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if(holder instanceof CategoryViewHolder) {
            final CategoryViewHolder categoryViewHolder = (CategoryViewHolder) holder;
            CategoryItem cgi = (CategoryItem) visibleItems.get(position);
            categoryViewHolder.category.setText(cgi.category.getName());

            categoryViewHolder.fold.setTag(holder);
            categoryViewHolder.fold.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    int holderPosition = ((CategoryViewHolder)buttonView.getTag()).getAdapterPosition();
                    if(isChecked) {
                        expandMemoItems(holderPosition);
                    }
                    else {
                        collapseMemoItems(holderPosition);
                    }
                }
            });
        }
        else if(holder instanceof MemoViewHolder) {
            final MemoViewHolder memoViewHolder = (MemoViewHolder) holder;
            MemoItem mmi = (MemoItem) visibleItems.get(position);
            memoViewHolder.delete.setVisibility(View.GONE);
            memoViewHolder.content.setText(mmi.memo.getContent());
            memoViewHolder.time.setText(mmi.memo.getTime());
            memoViewHolder.date.setText(mmi.memo.getDate());
            memoViewHolder.category.setText(mmi.memo.getCategory_name());
            memoViewHolder.mid.setText(String.valueOf(mmi.memo.getId()));
        }
    }

    private void expandMemoItems(int position) {
        CategoryItem cgi = (CategoryItem)visibleItems.get(position);
        int MemoSize = cgi.unvisibleMemoItems.size();

        for(int i = MemoSize - 1; i>=0; i--) {
            visibleItems.add(position + cgi.visibleMemoSize + 1, cgi.unvisibleMemoItems.get(i));
        }

        notifyItemRangeInserted(position + cgi.visibleMemoSize + 1, MemoSize);
    }

    private void collapseMemoItems(int position) {
        CategoryItem cgi = (CategoryItem)visibleItems.get(position);
        int MemoSize = cgi.unvisibleMemoItems.size();

        for(int i = 0; i < MemoSize; i++) {
            visibleItems.remove(position + cgi.visibleMemoSize + 1 );
        }

        notifyItemRangeRemoved(position + cgi.visibleMemoSize + 1 , MemoSize);
    }

    public class CategoryViewHolder extends RecyclerView.ViewHolder {
        protected TextView category;
        protected ToggleButton fold;

        public CategoryViewHolder(View view) {
            super(view);
            this.category = (TextView) view.findViewById(R.id.category_name);
            this.fold = (ToggleButton) view.findViewById(R.id.fold);
        }
    }

    public class MemoViewHolder extends RecyclerView.ViewHolder {
        protected View mView;
        protected ConstraintLayout cl;
        protected TextView content;
        protected TextView time;
        protected TextView date;
        protected TextView category;
        protected TextView mid;
        protected ImageButton delete;

        public MemoViewHolder(View view) {
            super(view);
            this.mView = view;
            this.cl = (ConstraintLayout) view.findViewById(R.id.Memo_container);
            this.content = (TextView) view.findViewById(R.id.Memo_content);
            this.time = (TextView) view.findViewById(R.id.Memo_time);
            this.date = (TextView) view.findViewById(R.id.Memo_date);
            this.category = (TextView) view.findViewById(R.id.Memo_category);
            this.mid = (TextView) view.findViewById(R.id.Memo_id);
            this.delete = (ImageButton) view.findViewById(R.id.Memo_delete);

            this.mView.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN : {
                            cl.setBackgroundColor(Color.rgb(220, 220, 220));
                            return true;
                        }
                        case MotionEvent.ACTION_MOVE:
                        case MotionEvent.ACTION_CANCEL:
                        case MotionEvent.ACTION_UP : {
                            cl.setBackgroundColor(Color.rgb(255, 255, 255));
                            return false;
                        }
                        default: {
                            break;
                        }
                    }
                    return false;
                }
            });
        }
    }

}

/*
* viewholder.category.setText(cList.get(position).getName());

        viewholder.eList.clear();
        viewholder.eList.addAll(db.getAllMemosByCategory(cList.get(position).getId()));

        if(viewholder.eList.size() != 0) {
            viewholder.vList = new ArrayList<Memo>(viewholder.eList.subList(0, (viewholder.eList.size() < 2 ? viewholder.eList.size() : 2)));
            viewholder.mAdapter = new MemoAdapter(context, viewholder.vList);
            viewholder.mRecyclerView.setAdapter(viewholder.mAdapter);

            viewholder.fold.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if(isChecked) {
                        viewholder.mAdapter = new MemoAdapter(context, viewholder.eList);
                        viewholder.mRecyclerView.setAdapter(viewholder.mAdapter);
                        /*int k = viewholder.vList.size();
                        viewholder.vList.clear();
                        viewholder.vList.addAll(viewholder.eList);
                        viewholder.mAdapter.notifyItemRangeInserted(k, viewholder.eList.size() - k);

                    }
                            else {
                            viewholder.mAdapter = new MemoAdapter(context, viewholder.vList);
                            viewholder.mRecyclerView.setAdapter(viewholder.mAdapter);
                        viewholder.vList.clear();
                        viewholder.vList.addAll(new ArrayList<Memo>(viewholder.eList.subList(0, (viewholder.eList.size() <= 2 ? viewholder.eList.size() : 2))));
                        viewholder.mAdapter.notifyItemRangeRemoved(viewholder.eList.size(), viewholder.eList.size() - viewholder.vList.size());
                            }
                            }
                            });
                            }
* */
